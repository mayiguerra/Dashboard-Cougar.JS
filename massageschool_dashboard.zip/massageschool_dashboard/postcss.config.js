module.exports = {
  plugins: {
    autoprefixer: {},
  },
};
